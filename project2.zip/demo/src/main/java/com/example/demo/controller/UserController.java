package com.example.demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.User;
import com.example.demo.service.UserRepository;

@RestController
@RequestMapping("/api")
public class UserController {
	
	@Autowired
	private UserRepository userRepository;

	@GetMapping("/users")
	public List<User> getAllUsers()
	{
		return userRepository.findAll();
	}
	
	@GetMapping("/users/{id}")
	public User findUser(@PathVariable (value="id") Long userId)
	{
	List<User> listOfUsers=userRepository.findAll();
	User user=null;
	for(User userTemp:listOfUsers)
	{
		if(userTemp.getId()==userId)
		{
			user=userTemp;
			break;
		}
	}
	return user;
	
	}
	
	@PostMapping("/users")
	public User createUser(@Valid @RequestBody User user)
	{
		User userTemp =new User();
		userTemp.setId(user.getId());
		userTemp.setUsername(user.getUsername());
		userTemp.setPassword(user.getPassword());
		userTemp.setStatus(user.getStatus());
		
		return userRepository.save(userTemp);
	}
	
	
	@PutMapping("/users/{id}")
	public User updateUser(@PathVariable (value="id") Long userId, @Valid @RequestBody User userDetails)
	{
		
		User user=new User();
		user.setId(userId);
		user.setUsername(userDetails.getUsername());
		user.setPassword(userDetails.getPassword());
		user.setStatus(userDetails.getStatus());
		
		return userRepository.save(user);
	}
	
	@DeleteMapping("/users/{id}")
	public User deleteUser(@PathVariable (value ="id") Long userID)
	{
	
		User userTemp=findUser(userID);
		
		if(userTemp!=null)
		{
			userRepository.delete(userTemp);
		}
		
		return userTemp;
	}
}
