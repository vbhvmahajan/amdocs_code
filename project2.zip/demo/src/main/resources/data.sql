insert into user values (1,'user1','pass1','actived');
insert into user values (2,'user2','pass2','deactived');